import { createWebHistory,createRouter } from "vue-router";
import HomePage from './components/Home.vue';
import AboutPage from './components/About.vue';
import ProfilePage from './components/profile.vue';

const routes=[
    {
        name:'Home',
        path:'/',
        component:HomePage
    },
    {
        name:'About',
        path:'/about',
        component:AboutPage
    },
    {
        name:'Profile',
        path:'/profile/:name',  //dynamic routing param
        component:ProfilePage
    }
];
const router= createRouter({
    history:createWebHistory(),
    routes
});
export default router;


