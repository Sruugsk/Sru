<template>
  <div>
    <router-link to="/">Home</router-link>
    <br/>
    <router-link to="/about">About</router-link>
    <br/>
    <router-link to="/profile/Admin">Admin Profile</router-link>
    <br/>
    <router-link to="/profile/User">User Profile</router-link>
    <br/>
    <router-link to="/profile/Main">Maintain Profile</router-link>
    <router-view></router-view>
  </div>
</template>
<script>

export default {
  name: 'App',
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
