<template>
    <div>
        <h1>Java</h1>
    </div>
</template>
<script>
export default ({
    name:"JP"
  
})
</script>
