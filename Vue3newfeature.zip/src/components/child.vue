<template>
    <div>
        <header><slot name="slot1">Happy Learning</slot></header>
        <br/>
        <content><slot name="slot2">Vue Js</slot></content>
        <br/><br/><br/><br/><br/>
        <footer style="text-align: left;"><slot name="slot3" >@copyrights sru.</slot></footer>
    </div>
</template>
<script>
export default ({
    name:"ChildPage"
  
})
</script>
