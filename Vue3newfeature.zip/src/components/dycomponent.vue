<template>
    <div>
        <h1>Dynamic Component</h1>
        <button @click="tab='JP'">React</button>
        <button @click="tab='DP'">Dotnet</button>
        <button @click="tab='PP'">Python</button>
        <component :is="tab"> </component>
    </div>
</template>
<script>
import JP from './React.vue';
import DP from './Dotnet.vue';
import PP from './python.vue';
export default ({
    name:'DynamicCom',
    components:
    {
        JP,
        DP,
        PP
    },
    data()
    {
        return{
            tab:'HomePage'
        }

    }
})
</script>
