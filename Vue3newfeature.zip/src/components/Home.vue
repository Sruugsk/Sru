<template>
    <div>
        <h1>Home Page</h1>
        <h2>Seconds Calculator {{a*b*c}} using function</h2>
        <h3>Seconds Calculator {{getseconds}} using computed property</h3>
        <button v-on:click="a=a+1" class="button"> Count Seconds</button>
        <teleport to='#Other'> 
            <div>
                <DynamicCom/>
                <JP/>
            </div>
        </teleport>
    </div>
</template>
<script>
import DynamicCom from './dycomponent.vue'
import JP from './React.vue'
export default ({
    name:"HomePage",
    component:
    {
DynamicCom,
JP
    },
    data() {
        return {
            a:1,
            b:60,
            c:60
        }
    },
    watch: {
        a(val)
        {
         if(val>12){
             alert("Day Is Done");
         }
        }
    },
    computed: {
        getseconds()
        {
            return (this.a*this.b*this.c)
        }
    }
})
</script>
<style scoped>
.button {
  border: none;
  background-color: #e7e7e7; color: black;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}
</style>
