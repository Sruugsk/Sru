<template>
<ChildPage>
    <template v-slot:header>
    <div>
        <h1 >Happy Learn</h1>
       </div>
</template>
<template v-slot:Content>
    <div>
        <h1>Vue JS</h1>
       </div>
</template>
<template v-slot:footer>
    <div>
        <h5>@copyrights sru.</h5>
       </div>
</template>
</ChildPage>
    
</template>
<script>
import ChildPage from './child.vue'
export default ({
    name:"AboutPage",
    components:
    {
        ChildPage
    }
})
</script>
