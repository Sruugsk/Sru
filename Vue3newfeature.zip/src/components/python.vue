<template>
    <div>
        <h1>Python</h1>
    </div>
</template>
<script>
export default ({
    name:"PP"
  
})
</script>
