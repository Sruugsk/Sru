<template>
    <div>
        <h1>Dotnet</h1>
    </div>
</template>
<script>
export default ({
    name:"DP"
  
})
</script>
