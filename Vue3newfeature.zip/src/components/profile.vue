<template>
    <div>
        <h1>{{profile}} Profile</h1>
        
    </div>
</template>
<script>
import {useRoute} from 'vue-router'

export default ({
    name:"ProfilePage",
    data() {
        return {
            profile:''
        }
    },
    
    mounted()
    {
        const rou=useRoute();
        console.warn("route",rou.params.name)
        this.profile=rou.params.name;
    },
    
})
</script>
