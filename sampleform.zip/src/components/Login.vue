<template>
<div>
    <form @submit="login">
        <input type="text" placeholder="Enter Username" v-model="logindata.username"/>
<br/><br/>
<input type="password" placeholder="Enter Password" v-model="logindata.password"/>
<br/><br/>
<input type="checkbox" value="AsianPacific Region" id="tdomain" v-model="logindata.region"/>
<label for="tdomain">Asian-Pacific Region Region </label>
<input type="checkbox" value="European Region" id="edomain" v-model="logindata.region"/>
<label for="edomain"> European Region</label>
<br/>
<input type="checkbox" value="Americas Region" id="adomain" v-model="logindata.region"/>
<label for="adomain">Americas Region </label>
<input type="checkbox" value="Oceania Region" id="odomain" v-model="logindata.region"/>
<label for="odomain"> Oceania Region</label>
<br/><br/>
<input type="radio" value="admin" id="admin" v-model="logindata.work"/>
<label for="admin"> Admin</label>
<input type="radio" value="support" id="support" v-model="logindata.work"/>
<label for="suport"> Support Agent</label>
<br/><br/>
<!-- <button v-on:click="login" type="submit">Login</button> -->
<button  type="submit">Login</button>
    </form>
</div>
</template>
<script>
export default {
   name:'LoginForm',
  data() {
      return {
          logindata:{
              error:[],
              username:null,
              password:null,
              region:[],
              work:null
          }
      }
  },
   methods:{
       login(e){
           if(this.logindata.username && this.logindata.password && this.logindata.region && this.logindata.work)
           {
              alert("Login Successful"+' '+this.logindata.username+' !!')
           }
           this.error=[];
           if(! (this.logindata.username && this.logindata.password && this.logindata.region && this.logindata.work))
           {
               this.error.push("Please fill all data")
               alert(this.error)
           }
        //    console.log("errors",this.error)
          e.preventDefault();
       },
      getlogin()
      {
          alert("Login Successful"+' '+this.logindata.username+' !!')
      } 

   }
}
</script>