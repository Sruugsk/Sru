<template>

  <h1>{{namedata}}</h1>
  <img alt="Vue logo" src="./assets/logo.png">
  <!-- <HelloWorld msg="Welcome to Your Vue.js App"/> -->
  <login-form/>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import LoginForm from './components/Login.vue'

export default {
  name: 'App',
  components: {
    //HelloWorld
    LoginForm
  },
  // computed:{
  //        uppercase(){
  //           return (v)=>{
  //             return v.toUpperCase()
  //             }
  //          }
  //    }
  data() {
    return {
      namedata:"Login Form"
    }
  },
}
</script>
<style >
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

