import '@babel/polyfill'
import 'mutationobserver-shim'
import { createApp } from 'vue'
import App from './App.vue'
import Vue from 'vue'


createApp(App).mount('#app')
Vue.config.productionTip = false;
    
Vue.filter('uppercase', function (v){
   return v.toUpperCase()
});
