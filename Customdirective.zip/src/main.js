import { createApp } from 'vue'
import App from './App.vue'

const app = createApp(App)
app.directive("theme", {
    mounted(el, binding) {
      if (binding.value === 'primary') {
        el.style.color = 'red'
      } else if (binding.value === 'secondary') {
        el.style.color = 'green'
      } else if (binding.value === 'tertiary') {
        el.style.color = 'blue'
      } else {
        el.style.color = 'black'
      }
    }
  })
 
  
  app.mount('#app')