<template>
<div>
<h1>Parent</h1>
<h3> Activity:{{gotname}}</h3>
<UserApp :getdatam="getdatamessage" />
</div>
</template>
<script>
import UserApp from './user.vue'
export default {
  name: "HomeApp",
  components:
  {
      UserApp
  },data() {
      return {
          gotname:''
      }
  },methods: {getdatamessage(name)
      {
          this.gotname=name
      }
  },
}
</script>

<style scoped>
h1{
    color:olive;
}
</style>


