<template>
<div>
<h3>Child</h3>
<button v-on:click="getdatam(sendme)"> Send </button>
</div>
</template>

<script>
export default {
  name: "UserApp",
  data() {
      return {
          sendme:"Sending Data"
      }
  },
  props:{
     getdatam :Function
  }
}
</script>


